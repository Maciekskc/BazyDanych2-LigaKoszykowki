create view TEAMS_STAT as
SELECT 
T.id as "ID",
    T.name,
   2*(select count(id) 
         from MATCH_RESULTS 
         where (host = T.name and (host_pts > guest_pts ))
         or    (guest = T.name and (host_pts < guest_pts)))
         +1*(select count(id) 
         from MATCH_RESULTS 
         where (host = T.name and (host_pts < guest_pts ))
         or    (guest = T.name and (host_pts > guest_pts)))
         as "PUNKTY",
          (select count(id) 
         from MATCH_RESULTS 
         where (host = T.name or guest = T.name) and host_pts != guest_pts) as "ROZEGRANE",
    (select count(id) 
         from MATCH_RESULTS 
         where (host = T.name and (host_pts > guest_pts ))
         or    (guest = T.name and (host_pts < guest_pts))) as "WYGRANE",
             (select count(id) 
         from MATCH_RESULTS 
         where (host = T.name and (host_pts < guest_pts ))
         or    (guest = T.name and (host_pts > guest_pts))) as "PRZEGRANE",
    (select sum("celne_2pt")
        from PLAYERS_STAT p
        where "druzyna" = t.name) as celne_2pt,
    (select sum("oddane_2pt")
        from PLAYERS_STAT p
        where "druzyna" = t.name) as oddane_2pt,
    NVL(ROUND(100*(select sum("celne_2pt") from PLAYERS_STAT p where "druzyna" = t.name)/
        NULLIF((select sum("oddane_2pt")from PLAYERS_STAT p where "druzyna" = t.name),0),1),0) || '%' as skutecznosc_2pt,
    (select sum("celne_3pt")
        from PLAYERS_STAT p
        where "druzyna" = t.name) as celne_3pt,
    (select sum("oddane_3pt")
        from PLAYERS_STAT p
        where "druzyna" = t.name) as oddane_3pt,
    NVL(ROUND(100*(select sum("celne_3pt") from PLAYERS_STAT p where "druzyna" = t.name)/
        NULLIF((select sum("oddane_3pt")from PLAYERS_STAT p where "druzyna" = t.name),0),1),0) || '%' as skutecznosc_3pt,
        (select sum("celne_1pt")
        from PLAYERS_STAT p
        where "druzyna" = t.name) as celne_1pt,
    (select sum("oddane_1pt")
        from PLAYERS_STAT p
        where "druzyna" = t.name) as oddane_1pt,
    NVL(ROUND(100*(select sum("celne_1pt") from PLAYERS_STAT p where "druzyna" = t.name)/
        NULLIF((select sum("oddane_1pt")from PLAYERS_STAT p where "druzyna" = t.name),0),1),0) || '%' as skutecznosc_1pt

FROM TEAMS T
ORDER BY PUNKTY DESC
/

