create view PLAYERS_STAT as
SELECT  p.id as "ID",
	e.name as "imie",
        e.surname as "nazwisko", 
        t.name as "druzyna",
         NVL((select count(id) from matches where teams_id1 = p.teams_id or teams_id = p.teams_id),0) as "rozegrane_mecze",
        NVL((select sum(value) from shots where players_id = p.id AND hit='1'),0)as "liczba_pkt",
        (select count(id) from shots where players_id = p.id and value=2 and hit='1') as "celne_2pt",
        (select count(id) from shots where players_id = p.id and value=2) as "oddane_2pt",
        NVL(ROUND(100*(select count(id) from shots where players_id = p.id and value=2 AND hit='1')/
             NULLIF((select count(id) from shots where players_id = p.id and value=2), 0),1),0) ||'%' as "skutecznosc_2pt",

        (select count(id) from shots where players_id = p.id and value=3 and hit='1') as "celne_3pt",
        (select count(id) from shots where players_id = p.id and value=3) as "oddane_3pt",
        NVL(ROUND(100*(select count(id) from shots where players_id = p.id and value=3 AND hit='1')/
             NULLIF((select count(id) from shots where players_id = p.id and value=3), 0),1),0) ||'%' as "skutecznosc_3pt",

        (select count(id) from shots where players_id = p.id and value=1 and hit='1') as "celne_1pt",
        (select count(id) from shots where players_id = p.id and value=1) as "oddane_1pt",
        NVL(ROUND(100*(select count(id) from shots where players_id = p.id and value=1 AND hit='1')/
             NULLIF((select count(id) from shots where players_id = p.id and value=1), 0),1),0) ||'%' as "skutecznosc_1pt"



FROM players p join people e on p.people_id = e.id
JOIN teams t on (t.id=p.teams_id)
ORDER BY "liczba_pkt" DESC
/

