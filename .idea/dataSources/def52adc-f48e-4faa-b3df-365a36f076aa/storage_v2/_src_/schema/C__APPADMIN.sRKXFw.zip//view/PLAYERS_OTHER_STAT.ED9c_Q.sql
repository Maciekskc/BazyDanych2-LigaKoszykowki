create view PLAYERS_OTHER_STAT as
SELECT  p.id as "ID",
	e.name as "imie",
        e.surname as "nazwisko", 
        t.name as "druzyna",          
         (select count(id) 
            from rebounds r 
            where players_id = p.id and p.teams_id=(SELECT teams_id 
                                                    FROM players  
                                                    WHERE id = (SELECT players_id 
                                                                        FROM shots 
                                                                        WHERE id = r.shots_id)))/
            NULLIF((select count(id) from matches where teams_id1 = p.teams_id or teams_id = p.teams_id),0) as "sr_zbiorek_o",
          (select count(id) 
            from rebounds r
            where players_id = p.id and p.teams_id!=(SELECT teams_id 
                                                    FROM players  
                                                    WHERE id = (SELECT players_id 
                                                                        FROM shots 
                                                                        WHERE id = r.shots_id)))/
            NULLIF((select count(id) from matches where teams_id1 = p.teams_id or teams_id = p.teams_id),0) as "sr_zbiorek_d",

            (select count(id) from rebounds where players_id = p.id)/
            NULLIF((select count(id) from matches where teams_id1 = p.teams_id or teams_id = p.teams_id),0) as "sr_zbiorek",
            (select count(id) from assists where players_id = p.id)/
            NULLIF((select count(id) from matches where teams_id1 = p.teams_id or teams_id = p.teams_id),0) as "sr_asyst",
            (select count(id) from blocks where players_id = p.id)/
            NULLIF((select count(id) from matches where teams_id1 = p.teams_id or teams_id = p.teams_id),0) as "sr_blokow",
              (select count(id) from turnovers where players_id = p.id)/
            NULLIF((select count(id) from matches where teams_id1 = p.teams_id or teams_id = p.teams_id),0) as "sr_strat",
              (select count(id) from steals where players_id = p.id)/
            NULLIF((select count(id) from matches where teams_id1 = p.teams_id or teams_id = p.teams_id),0) as "sr_przechwytow" 



FROM players p join people e on p.people_id = e.id
JOIN teams t on (t.id=p.teams_id)
/

