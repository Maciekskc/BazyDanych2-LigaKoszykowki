create view MATCH_RESULTS as
SELECT 
m.id as "ID",
t.name as "HOST",
d.name as "GUEST",
NVL((Select SUM(s.value) 
	from shots s 
		join incidents i on s.incidents_id = i.id
		join players p on s.players_id = p.id
	where
		m.id= i.matches_id AND
		t.id= p.teams_id AND
		s.hit = '1'),0)    as "HOST_PTS",
NVL((Select SUM(s.value) 
	from shots s 
		join incidents i on s.incidents_id = i.id
		join players p on s.players_id = p.id
	where
		m.id= i.matches_id AND
		d.id= p.teams_id AND
		s.hit = '1'),0) as "GUEST_PTS"

FROM MATCHES m 
    join teams t on m.teams_id = t.id
    join teams d on m.teams_id1 = d.id
ORDER BY m.ID ASC
/

